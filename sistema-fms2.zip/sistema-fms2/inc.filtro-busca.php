<?php
// Precisando de ajuda para desenvolver o seu sistema? acesse sistema-web-para.com.br e contrate uma assessoria...
?>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 bloco">
<div class="input-group">
<input autocomplete="<?php echo rand(); ?>" type="text" name="busca" class="form-control" placeholder="Busca" value="<?php echo $_GET['busca'] ?>">
<span class="input-group-btn">
<button class="btn btn-default" type="submit"><i class="fas fa-search"></i></button>
</span>
</div>
</div>
<div style="clear:both"></div>