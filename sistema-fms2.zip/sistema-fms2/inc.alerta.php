<?php
/*
<div class="alert alert-info" role="alert" style="margin-top: -30px;">...</div>
*/
?>