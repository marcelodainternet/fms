<?php
// Precisando de ajuda para desenvolver o seu sistema? acesse sistema-web-para.com.br e contrate uma assessoria...
?>
<h2>Seu Logo Aqui</h2>
<p>Seu Slogan Aqui</p>